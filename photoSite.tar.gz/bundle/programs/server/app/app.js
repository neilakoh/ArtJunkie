var require = meteorInstall({"lib":{"collections":{"index.js":["./wspay_tester",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/index.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
exports.WspayTester = exports.undefined = undefined;                                              //
                                                                                                  //
var _wspay_tester = require('./wspay_tester');                                                    // 1
                                                                                                  //
var _wspay_tester2 = _interopRequireDefault(_wspay_tester);                                       //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
exports.undefined = undefined;                                                                    //
exports.WspayTester = _wspay_tester2['default'];                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"wspay_tester.js":["meteor/mongo",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/wspay_tester.js                                                                //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 1
                                                                                                  //
var WspayTester = new _mongo.Mongo.Collection('wspay_tester');                                    // 3
                                                                                                  //
exports['default'] = WspayTester;                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"methods":{"index.js":["./wspay_tester",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/index.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _wspay_tester2['default'])();                                                               // 4
};                                                                                                // 5
                                                                                                  //
var _wspay_tester = require('./wspay_tester');                                                    // 1
                                                                                                  //
var _wspay_tester2 = _interopRequireDefault(_wspay_tester);                                       //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"wspay_tester.js":["/lib/collections","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/wspay_tester.js                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 6
    'wspay_tester.sample': function wspay_testerSample() {}                                       // 7
  });                                                                                             // 6
};                                                                                                // 11
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"index.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/index.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
"use strict";                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports["default"] = function () {};                                                              //
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":["./publications","./methods",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/main.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
var _publications = require('./publications');                                                    // 1
                                                                                                  //
var _publications2 = _interopRequireDefault(_publications);                                       //
                                                                                                  //
var _methods = require('./methods');                                                              // 2
                                                                                                  //
var _methods2 = _interopRequireDefault(_methods);                                                 //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
(0, _publications2['default'])();                                                                 // 4
(0, _methods2['default'])();                                                                      // 5
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/collections/index.js");
require("./lib/collections/wspay_tester.js");
require("./server/methods/index.js");
require("./server/methods/wspay_tester.js");
require("./server/publications/index.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
